# NUZ_Guitars
A small business and supporting website for a mock small business plan as a capstone project in C102.
